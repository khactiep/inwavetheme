<?php
/*
 * @package Inwave Booking
 * @version 1.0.0
 * @created Ma5 12, 2015
 * @author Inwavethemes
 * @email inwavethemes@gmail.com
 * @website http://inwavethemes.com
 * @support Ticket https://inwave.ticksy.com/
 * @copyright Copyright (c) 2015 Inwavethemes. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 *
 */

/**
 * Description of extrafield
 *
 * @developer duongca
 */
$utility->getNoticeMessage();
?>
<div class="iwe-wrap wrap">
    <h2 class="in-title"><?php echo __('Bookings', 'inwavethemes'); ?>
        <a class="bt-button add-new-h2" href ="javascript:void(0);" onclick="javascript:document.getElementById('speakers-form').submit();
                return false;"><?php echo __("Delete"); ?></a>
    </h2>
    <form action="<?php echo admin_url(); ?>admin-post.php" method="post" name="filter">
        <div class="iwe-filter tablenav top">
            <div class="alignleft">
                <label><?php _e('Filter', 'inwavethemes'); ?></label>
                <input type="text" name="keyword" value="<?php echo filter_input(INPUT_GET, 'keyword'); ?>" placeholder="<?php echo __('Input keyword to search', 'inwavethemes'); ?>"/>
                <input type="text" name="date_from" value="<?php echo filter_input(INPUT_GET, 'date_to'); ?>"/>
                <input type="text" name="date_to" value="<?php echo filter_input(INPUT_GET, 'date_from'); ?>"/>
            </div>
            <div class="alignleft">
                <input type="hidden" value="inMedicalFilter" name="action"/>
                <input class="button" type="submit" value="<?php _e('Search', 'inwavethemes'); ?>"/>
            </div>
        </div>
    </form>
    <form id="speakers-form" action="<?php echo admin_url(); ?>admin-post.php" method="post">
        <input type="hidden" name="action" value="inMedicalDeleteBookings"/>
        <table class="iwbooking-list-table wp-list-table widefat fixed posts">
            <thead>
                <tr>
                    <th scope="col" id="cb" class="manage-column column-cb check-column" style="width: 5%">
                        <label class="screen-reader-text" for="cb-select-all-1"><?php echo __('Select All', 'inwavethemes'); ?></label>
                        <input id="cb-select-all-1" type="checkbox">
                    </th>
                    <th scope="col" id="name" class="manage-column column-author" style="width: 30%"><?php echo __('Customer name', 'inwavethemes'); ?></th>
                    <th scope="col" id="type" class="manage-column column-categories" style="width: 20%"><?php echo __('Event name', 'inwavethemes'); ?></th>
                    <th scope="col" id="type" class="manage-column column-categories" style="width: 20%"><?php echo __('Event Date', 'inwavethemes'); ?></th>
                    <th scope="col" id="Published" class="manage-column column-categories" style="width: 15%"><?php echo __('Email', 'inwavethemes'); ?></th>
                    <th scope="col" id="Published" class="manage-column column-categories" style="width: 15%"><?php echo __('Status', 'inwavethemes'); ?></th>
                </tr>
            </thead>

            <tbody id="the-list">
                <?php
                if (!empty($bookings)) {
                    foreach ($bookings as $app) {
                        ?>
                        <tr>
                            <th scope="row" class="check-column">
                                <input id="cb-select-1" type="checkbox" name="fields[]" value="<?php echo $app->getId(); ?>"/>
                                <div class="locked-indicator"></div>
                            </th>
                            <td>
                                <a href="<?php echo admin_url('edit.php?post_type=indepartment&page=booking/edit&id=' . $app->getId()); ?>" title="<?php echo __('view this item', 'inwavethemes'); ?>">
                                    <strong><?php echo ($app->getFirst_name() . ' ' . $app->getLast_name()); ?></strong>
                                </a>
                                <div class="row-actions">
                                    <a href="<?php echo admin_url('edit.php?post_type=indepartment&page=booking/edit&id=' . $app->getId()); ?>" title="<?php echo __('Edit this item', 'inwavethemes'); ?>"><?php echo __('Edit', 'inwavethemes'); ?></a> |
                                    <a class="submitdelete" title="<?php echo __('Move this item to the Trash', 'inwavethemes'); ?>" href="<?php echo admin_url("admin-post.php?action=inMedicalDeleteBooking&id=" . $app->getId()); ?>"><?php echo __('Delete', 'inwavethemes'); ?></a>
                                </div>
                            </td>
                            <td><?php
                                $event = get_post($app->getEvent_post());
                                print($event->post_title);
                                ?></td>

                            <td><?php
                                echo date_i18n(get_option('date_format'), $app->getAppointment_date());
                                ?></td>
                            <td><?php echo $app->getEmail(); ?></td>
                            <td><div class="booking-status"><?php echo $app->getStatus() == 1 ? '<span class="accepted">' . __('Accepted', 'inwavethemes') . '</span>' : (($app->getStatus() == 2) ? '<span class="cancel">' . __('Cancel', 'inwavethemes') . '</span>' : '<span data-id="'.$app->getId().'" title="'.__('Click to quick accept','inwavethemes').'" class="pendding">' . __('Accept now', 'inwavethemes') . '</span>'); ?></div></td>
                        </tr>
                    <?php }
                    ?>
                    <tr>
                        <td colspan="5">
                            <?php
                            $page_list = $paging->pageList($_GET['pagenum'], $pages);
                            echo $page_list;
                            ?>
                        </td>
                    </tr> 
                <?php } else { ?>
                    <tr>
                        <td colspan="5"><?php echo __('No result', 'inwavethemes'); ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </form>
</div>
