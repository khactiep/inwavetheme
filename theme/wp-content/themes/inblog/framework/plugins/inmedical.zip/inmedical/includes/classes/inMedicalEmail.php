<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class IMD_Email {
    static function register_email_shortcodes(){
        add_shortcode('ime_site_name', array(__CLASS__, 'site_name_shortcode'));
        add_shortcode('ime_site_url', array(__CLASS__, 'site_url_shortcode'));
        add_shortcode('ime_admin_email', array(__CLASS__, 'admin_email_shortcode'));
        add_shortcode('ime_booking_id', array(__CLASS__, 'booking_id_shortcode'));
        add_shortcode('ime_booking_edit_link', array(__CLASS__, 'booking_edit_link_shortcode'));
        add_shortcode('ime_first_name', array(__CLASS__, 'first_name_shortcode'));
        add_shortcode('ime_last_name', array(__CLASS__, 'last_name_shortcode'));
        add_shortcode('ime_email', array(__CLASS__, 'email_shortcode'));
        add_shortcode('ime_phone', array(__CLASS__, 'phone_shortcode'));
        add_shortcode('ime_reason', array(__CLASS__, 'reason_shortcode'));
        add_shortcode('ime_department', array(__CLASS__, 'department_shortcode'));
        add_shortcode('ime_doctor', array(__CLASS__, 'doctor_shortcode'));
        add_shortcode('ime_date', array(__CLASS__, 'date_shortcode'));
    }

    static function site_name_shortcode($atts){
        return get_bloginfo( 'name' );
    }
    static function site_url_shortcode($atts){
        return network_site_url( '/' );
    }
    static function admin_email_shortcode($atts){
        return get_bloginfo( 'admin_email' );
    }
    static function booking_id_shortcode($atts){
        global $ime_data;
        return isset($ime_data['booking_id']) ? '#'.$ime_data['booking_id'] : '';
    }
    static function booking_edit_link_shortcode($atts){
        global $ime_data;
        if(isset($ime_data['booking_id'])){
            return '<a href="'.get_edit_post_link($ime_data['booking_id']).'">'.get_the_title($ime_data['booking_id']).'</a>';
        }
        return '';
    }
    static function first_name_shortcode(){
        global $ime_data;
        if(!$ime_data || !isset($ime_data['first_name'])){
            return '';
        }
        return $ime_data['first_name'];
    }
    static function last_name_shortcode($atts){
        global $ime_data;
        if(!$ime_data || !isset($ime_data['last_name'])){
            return '';
        }
        return $ime_data['last_name'];
    }
    static function email_shortcode($atts){
        global $ime_data;
        if(!$ime_data || !isset($ime_data['email'])){
            return '';
        }
        return $ime_data['email'];
    }
    static function phone_shortcode($atts){
        global $ime_data;
        if(!$ime_data || !isset($ime_data['phone'])){
            return '';
        }
        return $ime_data['phone'];
    }
    static function reason_shortcode($atts){
        global $ime_data;
        if(!$ime_data || !isset($ime_data['reason'])){
            return '';
        }
        return $ime_data['reason'];
    }
    static function department_shortcode($atts){
        $atts = shortcode_atts( array(
            'link' => 'false',
        ), $atts, 'ime_department' );

        global $ime_data;
        if(!$ime_data || !isset($ime_data['booking_id'])){
            return '';
        }

        $booking = IMD_Booking_Appointment::init($ime_data['booking_id']);
        if($booking){
            $appointment_id = $booking->get_appointment_id();
            $appointment = IMD_Appointment::init($appointment_id);
            if($appointment){
                $doctor_id = $appointment->get_doctor();
                $department_id = get_post_meta($doctor_id, 'imd_doctor_info_department', true);
                if($department_id){
                    if($atts['link'] == 'true'){
                        return '<a href="'.get_permalink($department_id).'">'.get_the_title($department_id).'</a>';
                    }
                    else{
                        return get_the_title($department_id);
                    }
                }
            }
        }

        return '';
    }
    static function doctor_shortcode($atts){
        $atts = shortcode_atts( array(
            'link' => 'false',
        ), $atts, 'ime_doctor' );

        global $ime_data;
        if(!$ime_data || !isset($ime_data['booking_id'])){
            return '';
        }

        $booking = IMD_Booking_Appointment::init($ime_data['booking_id']);
        if($booking){
            $appointment_id = $booking->get_appointment_id();
            $appointment = IMD_Appointment::init($appointment_id);
            if($appointment){
                $doctor_id = $appointment->get_doctor();
                if($doctor_id){
                    if($atts['link'] == 'true'){
                        return '<a href="'.get_permalink($doctor_id).'">'.get_the_title($doctor_id).'</a>';
                    }
                    else{
                        return get_the_title($doctor_id);
                    }
                }
            }
        }

        return '';
    }
    static function date_shortcode($atts){
        $atts = shortcode_atts( array(
            'fortmat' => '',
        ), $atts, 'ime_date' );

        global $ime_data;
        if(!$ime_data || !isset($ime_data['booking_id'])){
            return '';
        }
        $format = $atts['format'] ? $atts['format'] : get_option('date_format');
        $date = get_post_meta($ime_data['booking_id'], 'imd_date', true);
        $return = $date ? date($format, $date) : '';
        $booking = IMD_Booking_Appointment::init($ime_data['booking_id']);
        if($booking){
            $appointment_id = $booking->get_appointment_id();
            $appointment = IMD_Appointment::init($appointment_id);
            if($appointment){
                $return .= ' '.$appointment->get_time_range();
            }
        }

        return $return;
    }

	static public function sendMail ($type, $booking_id) {
		if($type && $booking_id){
            global $imd_settings, $ime_data;
            $emails = isset($imd_settings['emails']) ? $imd_settings['emails'] : array();
            if(isset($emails[$type]['enable']) && $emails[$type]['enable'] == 1){
                $booking = IMD_Booking_Appointment::init($booking_id);
                $ime_data = array(
                    'booking_id' => $booking_id,
                    'first_name' => $booking->get_first_name(),
                    'last_name' => $booking->get_last_name(),
                    'email' => $booking->get_email(),
                    'phone' => $booking->get_phone(),
                    'reason' => $booking->get_phone(),
                );

                $from_name = get_bloginfo('name');
                $from_address = get_bloginfo('admin_email');
                if(strpos($type, 'admin_') === 0){
                    $recipient = get_bloginfo( 'admin_email');
                }
                else{
                    $recipient = $booking->get_email();
                }

                $subject = strip_tags(apply_filters('the_content', $emails[$type]['title']));
                $content = apply_filters('the_content', stripslashes($emails[$type]['content']));

                if($recipient){
                    $headers = array();
                    $headers[] = 'Content-Type: text/html; charset=UTF-8';
                    $headers[] = 'From: '.$from_name.' <'.$from_address.'>';
                    wp_mail($recipient, $subject, $content, $headers);
                    return true;
                }
            }
		}

		return false;
	}
}

IMD_Email::register_email_shortcodes();