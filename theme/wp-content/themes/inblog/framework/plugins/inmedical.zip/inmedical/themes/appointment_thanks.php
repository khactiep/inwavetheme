<div class="imd-booked-thanks">
    <i class="ion-android-checkmark-circle"></i>
    <h3 class="booked-thanks-title"><?php echo __('Congratulation!', 'inmedical'); ?></h3>
    <div class="booked-thanks-message">
        <div class="text"><?php echo __('Your appointment request has been sent. We will sent you<br> a confirmation email.', 'inwavethemes'); ?></div>
        <div class="thank"><?php echo __('Thank you so much!', 'inwavethemes'); ?></div>
    </div>
    <div class="booked-info">
        <?php
        //$booked_id;
        ?>
    </div>
</div>