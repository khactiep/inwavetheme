<?php if ($doctors):
	$sliderConfig = '{';
	$sliderConfig .= '"navigation":'.$show_navigation;
	$sliderConfig .= ',"autoPlay":'.$auto_play;
	$sliderConfig .= ',"pagination":false';
	$sliderConfig .= ',"items":'.esc_attr($item_desktop ? $item_desktop : 3);
	// if ($single_item){
		// $sliderConfig .= ',"singleItem":true';
	// }
	$sliderConfig .= ',"itemsDesktop":[1199,'.esc_attr($item_desktop ? $item_desktop : 3).']';
	$sliderConfig .= ',"itemsDesktopSmall":[991,'.esc_attr($item_desktop_small ? $item_desktop_small : 2).']';
	$sliderConfig .= ',"itemsTablet":[768,1]';
	$sliderConfig .= ',"itemsMobile":[479,1]';
    $sliderConfig .= ',"navigationText": ["<i class=\"fa fa-angle-left\"></i>", "<i class=\"fa fa-angle-right\"></i>"]';
	$sliderConfig .= '}';
	
    wp_enqueue_style('owl-carousel');
    wp_enqueue_style('owl-theme');
    wp_enqueue_style('owl-transitions');
    wp_enqueue_script('owl-carousel');
    ?>
	
	
	<div class="iw-doctors style1 <?php echo $class ?>">
						
                        <div class="iw-doctor-list">
							<div class="owl-carousel" data-plugin-options='<?php echo $sliderConfig; ?>'>
								<?php foreach ($doctors as $d){ ?>
								<?php
									$doctor_info = $doctor->getDoctorInformation($d);
								?>
									<div class="content-item">
										<div class="content-item-inner">
											<?php 
											if ($doctor_info->image){
												$image = wp_get_attachment_image_src(get_post_thumbnail_id($doctor_info->id), 'full');
												$url_img = inwave_resize($image[0], 370, 255, array('center', 'top'));
											?>
												<div class="content-image">
                                                    <img alt="" src="<?php echo esc_url($url_img);?>"/>
													<?php if ($doctor_info->social_links && !empty($doctor_info->social_links)){ ?>
														<div class="social-link">
															<ul>
																<?php
																foreach ($doctor_info->social_links as $social_link) {
																	echo '<li class="' . $social_link['key_title'] . '"><a class="theme-bg" href="' . $social_link['key_value'] . '"><i class="fa fa-' . $social_link['key_title'] . '"></i></a></li>';
																}
																?>
															</ul>
														</div>
													<?php } ?>
												</div>
											<?php } ?>
											
												<div class="content-detail">
													<div class="content-info">
														<h3 class="title">
															<a class="theme-color-hover" href="<?php echo get_permalink($doctor_info->id); ?>"><?php echo $doctor_info->title; ?></a>
														</h3>
														<?php if ($doctor_info->department){
                                                            $department_link = get_permalink($doctor_info->department->id);
                                                            ?>
															<div class="doctor-department">
                                                                <a href="<?php print($department_link); ?>"><?php echo $doctor_info->department->title; ?></a>
															</div>
														<?php } ?>
													</div>
													<div class="content-description">
														<?php print($utility->truncateString($doctor_info->content, $desc_text_limit ? $desc_text_limit : 20)); ?>
													</div>
													<div class="readmore">
														<a class="" href="<?php echo get_permalink($doctor_info->id); ?>"><?php echo esc_html__('View profile', 'inwavethemes') ;?></a>
													</div>
												</div>
										</div>
									</div>
								<?php } ?>
							</div>
                        </div>
					</div>
	

    <?php endif; ?>